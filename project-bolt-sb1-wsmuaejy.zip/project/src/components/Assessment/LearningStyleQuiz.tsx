import React, { useState } from 'react';
import Button from '../UI/Button';
import Card, { CardBody, CardFooter } from '../UI/Card';
import { LearningPreference } from '../../types';

interface Question {
  id: number;
  text: string;
  primaryStyle: string;
}

const questions: Question[] = [
  {
    id: 1,
    text: "When learning a new skill, I prefer to...",
    primaryStyle: "visual"
  },
  {
    id: 2,
    text: "I remember information best when...",
    primaryStyle: "auditory"
  },
  {
    id: 3,
    text: "When solving a problem, I tend to...",
    primaryStyle: "reading"
  },
  {
    id: 4,
    text: "When I'm teaching someone something new, I typically...",
    primaryStyle: "kinesthetic"
  },
  {
    id: 5,
    text: "I find it easiest to understand complex topics when they are presented as...",
    primaryStyle: "visual"
  }
];

const answers = [
  {
    id: "a",
    text: "Watch a demonstration or video",
    style: "visual"
  },
  {
    id: "b",
    text: "Listen to detailed instructions",
    style: "auditory"
  },
  {
    id: "c",
    text: "Read step-by-step instructions",
    style: "reading"
  },
  {
    id: "d",
    text: "Try it myself through hands-on practice",
    style: "kinesthetic"
  }
];

interface LearningStyleQuizProps {
  onComplete: (preferences: LearningPreference[]) => void;
}

const LearningStyleQuiz: React.FC<LearningStyleQuizProps> = ({ onComplete }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selections, setSelections] = useState<Record<number, string>>({});
  const [isCompleted, setIsCompleted] = useState(false);
  
  const handleSelection = (questionId: number, answerStyle: string) => {
    setSelections(prev => ({
      ...prev,
      [questionId]: answerStyle
    }));
  };
  
  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      // Calculate results
      const results = calculateResults();
      setIsCompleted(true);
      onComplete(results);
    }
  };
  
  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };
  
  const calculateResults = (): LearningPreference[] => {
    const styles = ["visual", "auditory", "reading", "kinesthetic"];
    const counts: Record<string, number> = {};
    
    // Initialize counts
    styles.forEach(style => {
      counts[style] = 0;
    });
    
    // Count selections
    Object.values(selections).forEach(style => {
      counts[style]++;
    });
    
    // Convert to percentages
    const total = Object.values(counts).reduce((sum, count) => sum + count, 0);
    
    return styles.map(style => ({
      style: style as any,
      strength: Math.round((counts[style] / total) * 100)
    }));
  };
  
  const question = questions[currentQuestion];
  const isAnswered = selections[question.id] !== undefined;
  
  const progressPercentage = Math.round(((currentQuestion + 1) / questions.length) * 100);
  
  return (
    <Card className="max-w-2xl mx-auto">
      <CardBody>
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-lg font-semibold text-gray-900">Learning Style Assessment</h3>
            <span className="text-sm text-gray-500">Question {currentQuestion + 1} of {questions.length}</span>
          </div>
          
          {/* Progress bar */}
          <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
            <div 
              className="bg-blue-600 rounded-full h-2 transition-all duration-500 ease-out"
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
          
          <p className="text-gray-600 text-sm">
            This quick assessment will help us understand your learning preferences and tailor content to your style.
          </p>
        </div>
        
        <div className="mb-6">
          <h4 className="text-xl font-medium text-gray-800 mb-4">{question.text}</h4>
          
          <div className="space-y-3">
            {answers.map((answer) => (
              <div 
                key={answer.id}
                className={`
                  p-4 rounded-lg border cursor-pointer transition-all duration-200
                  ${selections[question.id] === answer.style
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-blue-300 hover:bg-blue-50/30'
                  }
                `}
                onClick={() => handleSelection(question.id, answer.style)}
              >
                <div className="flex items-center">
                  <div 
                    className={`
                      h-5 w-5 rounded-full border flex items-center justify-center mr-3
                      ${selections[question.id] === answer.style
                        ? 'border-blue-500'
                        : 'border-gray-300'
                      }
                    `}
                  >
                    {selections[question.id] === answer.style && (
                      <div className="h-3 w-3 rounded-full bg-blue-500"></div>
                    )}
                  </div>
                  <span className="text-gray-700">{answer.text}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardBody>
      
      <CardFooter className="flex justify-between">
        <Button 
          variant="outline" 
          onClick={prevQuestion}
          disabled={currentQuestion === 0}
        >
          Previous
        </Button>
        
        <Button 
          variant="primary" 
          onClick={nextQuestion}
          disabled={!isAnswered}
        >
          {currentQuestion === questions.length - 1 ? 'Finish' : 'Next'}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default LearningStyleQuiz;