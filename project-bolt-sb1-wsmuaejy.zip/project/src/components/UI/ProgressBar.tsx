import React from 'react';

interface ProgressBarProps {
  progress: number; // 0-100
  size?: 'sm' | 'md' | 'lg';
  color?: 'primary' | 'secondary' | 'success' | 'warning' | 'error';
  showPercentage?: boolean;
  className?: string;
  animated?: boolean;
}

const ProgressBar: React.FC<ProgressBarProps> = ({
  progress,
  size = 'md',
  color = 'primary',
  showPercentage = false,
  className = '',
  animated = false
}) => {
  // Ensure progress is between 0-100
  const normalizedProgress = Math.min(Math.max(progress, 0), 100);
  
  const sizeClasses = {
    sm: 'h-1',
    md: 'h-2',
    lg: 'h-4'
  };
  
  const colorClasses = {
    primary: 'bg-blue-600',
    secondary: 'bg-purple-600',
    success: 'bg-green-500',
    warning: 'bg-yellow-500',
    error: 'bg-red-500'
  };
  
  const animationClass = animated ? 'transition-all duration-500 ease-in-out' : '';
  
  return (
    <div className={`w-full ${className}`}>
      <div className="w-full bg-gray-200 rounded-full overflow-hidden">
        <div 
          className={`${sizeClasses[size]} ${colorClasses[color]} rounded-full ${animationClass}`}
          style={{ width: `${normalizedProgress}%` }}
        />
      </div>
      
      {showPercentage && (
        <div className="text-xs text-gray-500 mt-1 text-right">
          {normalizedProgress}%
        </div>
      )}
    </div>
  );
};

export default ProgressBar;