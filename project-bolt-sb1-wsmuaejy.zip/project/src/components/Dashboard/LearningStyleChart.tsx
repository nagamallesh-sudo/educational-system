import React from 'react';
import { LearningPreference } from '../../types';

interface LearningStyleChartProps {
  learningPreferences: LearningPreference[];
}

const LearningStyleChart: React.FC<LearningStyleChartProps> = ({ learningPreferences }) => {
  const maxValue = 100; // Maximum value for the chart

  // Style mapping for different learning styles
  const styleColors = {
    visual: {
      bg: 'bg-blue-500',
      text: 'text-blue-700',
      border: 'border-blue-600'
    },
    auditory: {
      bg: 'bg-purple-500',
      text: 'text-purple-700',
      border: 'border-purple-600'
    },
    reading: {
      bg: 'bg-teal-500',
      text: 'text-teal-700',
      border: 'border-teal-600'
    },
    kinesthetic: {
      bg: 'bg-orange-500',
      text: 'text-orange-700',
      border: 'border-orange-600'
    }
  };

  // Style name mapping
  const styleNames = {
    visual: 'Visual',
    auditory: 'Auditory',
    reading: 'Reading',
    kinesthetic: 'Kinesthetic'
  };

  return (
    <div className="rounded-lg bg-white shadow p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Your Learning Style Profile</h3>
      
      <div className="space-y-4">
        {learningPreferences.map((pref) => (
          <div key={pref.style} className="mb-4">
            <div className="flex justify-between items-center mb-1">
              <span className={`text-sm font-medium ${styleColors[pref.style].text}`}>
                {styleNames[pref.style]}
              </span>
              <span className="text-sm font-medium text-gray-600">{pref.strength}%</span>
            </div>
            <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
              <div 
                style={{ width: `${pref.strength}%` }}
                className={`${styleColors[pref.style].bg} rounded transition-all duration-500 ease-out shadow-none flex flex-col text-center whitespace-nowrap justify-center`}
              ></div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-6 pt-4 border-t border-gray-200">
        <h4 className="text-sm font-medium text-gray-700 mb-2">What This Means</h4>
        <p className="text-sm text-gray-600">
          Your profile shows you learn best through {getDominantStyle(learningPreferences)} methods. 
          We'll prioritize content that matches your learning preferences while also including 
          varied formats to help strengthen your other learning modes.
        </p>
      </div>
    </div>
  );
};

// Helper function to determine the dominant learning style
function getDominantStyle(learningPreferences: LearningPreference[]): string {
  if (!learningPreferences.length) return 'varied';
  
  const sorted = [...learningPreferences].sort((a, b) => b.strength - a.strength);
  const dominant = sorted[0];
  
  const styleDescriptions = {
    visual: 'visual (images, diagrams, videos)',
    auditory: 'auditory (listening, discussions)',
    reading: 'reading/writing (text, notes)',
    kinesthetic: 'hands-on (practice, interactive activities)'
  };
  
  return styleDescriptions[dominant.style];
}

export default LearningStyleChart;