import React from 'react';
import { BookOpen, ChevronRight, Award } from 'lucide-react';
import Card, { CardBody, CardFooter } from '../UI/Card';
import Button from '../UI/Button';
import { LearningPath } from '../../types';
import ProgressBar from '../UI/ProgressBar';

interface LearningPathCardProps {
  path: LearningPath;
  progress?: number; // 0-100
}

const LearningPathCard: React.FC<LearningPathCardProps> = ({ path, progress = 0 }) => {
  return (
    <Card hoverable className="h-full">
      <CardBody>
        <div className="flex items-start">
          <div className="p-2 rounded-lg bg-blue-100 text-blue-600 mr-4">
            <BookOpen className="h-6 w-6" />
          </div>
          
          <div className="flex-1">
            <h3 className="font-semibold text-lg text-gray-900 mb-1">{path.title}</h3>
            <p className="text-gray-600 text-sm mb-4">{path.description}</p>
            
            <div className="flex flex-wrap gap-2 mb-4">
              {path.topics.map(topic => (
                <span 
                  key={topic}
                  className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                >
                  {topic}
                </span>
              ))}
            </div>
            
            <div className="mb-4">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-medium text-gray-600">Progress</span>
                <span className="text-xs font-medium text-gray-600">{progress}%</span>
              </div>
              <ProgressBar progress={progress} size="sm" color="primary" animated />
            </div>
            
            <div className="text-sm text-gray-700">
              <div className="flex justify-between mb-2">
                <span>Content modules:</span>
                <span className="font-medium">{path.contentSequence.length}</span>
              </div>
              <div className="flex justify-between">
                <span>Assessments:</span>
                <span className="font-medium">{path.assessments.length}</span>
              </div>
            </div>
          </div>
        </div>
      </CardBody>
      
      <CardFooter className="flex justify-between items-center bg-gray-50">
        <div className="flex items-center text-xs text-gray-500">
          {progress === 100 ? (
            <>
              <Award className="h-4 w-4 text-green-500 mr-1" />
              <span className="text-green-600 font-medium">Completed</span>
            </>
          ) : progress > 0 ? (
            <>
              <BookOpen className="h-4 w-4 text-blue-500 mr-1" />
              <span className="text-blue-600 font-medium">In progress</span>
            </>
          ) : (
            <>
              <BookOpen className="h-4 w-4 text-gray-400 mr-1" />
              <span>Not started</span>
            </>
          )}
        </div>
        
        <Button 
          variant="text" 
          size="sm"
          icon={<ChevronRight className="h-4 w-4" />}
          iconPosition="right"
          onClick={() => window.location.href = `/learning-path/${path.id}`}
        >
          {progress > 0 ? 'Continue' : 'Start'}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default LearningPathCard;