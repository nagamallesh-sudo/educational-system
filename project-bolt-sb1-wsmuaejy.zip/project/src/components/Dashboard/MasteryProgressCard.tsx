import React from 'react';
import { Ban as Bar, CheckCircle, Circle } from 'lucide-react';
import ProgressBar from '../UI/ProgressBar';

interface MasteryProgressCardProps {
  masteryData: Record<string, number>;
}

const MasteryProgressCard: React.FC<MasteryProgressCardProps> = ({ masteryData }) => {
  // Sort by mastery level (highest first)
  const sortedTopics = Object.entries(masteryData)
    .sort(([, valueA], [, valueB]) => valueB - valueA);

  const getMasteryStatus = (value: number): { label: string; color: string } => {
    if (value >= 80) {
      return { label: 'Mastered', color: 'text-green-500' };
    } else if (value >= 60) {
      return { label: 'Proficient', color: 'text-blue-500' };
    } else if (value >= 40) {
      return { label: 'Developing', color: 'text-yellow-500' };
    } else {
      return { label: 'Beginning', color: 'text-gray-500' };
    }
  };

  return (
    <div className="rounded-lg bg-white shadow p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Topic Mastery</h3>
        <button className="text-gray-400 hover:text-gray-600 transition-colors">
          <Bar className="h-4 w-4" />
        </button>
      </div>
      
      <div className="space-y-6">
        {sortedTopics.map(([topic, value]) => {
          const status = getMasteryStatus(value);
          
          return (
            <div key={topic}>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium capitalize">{topic}</span>
                <span className={`text-xs font-medium ${status.color}`}>
                  {status.label}
                </span>
              </div>
              
              <div className="mb-2">
                <ProgressBar 
                  progress={value} 
                  size="md" 
                  color={value >= 80 ? 'success' : value >= 60 ? 'primary' : value >= 40 ? 'warning' : 'error'}
                  animated
                />
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex space-x-4 text-xs text-gray-500">
                  <div className="flex items-center">
                    {value >= 80 ? (
                      <CheckCircle className="h-3 w-3 text-green-500 mr-1" />
                    ) : (
                      <Circle className="h-3 w-3 text-gray-300 mr-1" />
                    )}
                    <span>Concept</span>
                  </div>
                  
                  <div className="flex items-center">
                    {value >= 60 ? (
                      <CheckCircle className="h-3 w-3 text-green-500 mr-1" />
                    ) : (
                      <Circle className="h-3 w-3 text-gray-300 mr-1" />
                    )}
                    <span>Application</span>
                  </div>
                  
                  <div className="flex items-center">
                    {value >= 40 ? (
                      <CheckCircle className="h-3 w-3 text-green-500 mr-1" />
                    ) : (
                      <Circle className="h-3 w-3 text-gray-300 mr-1" />
                    )}
                    <span>Practice</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="mt-6 pt-4 border-t border-gray-200">
        <button className="text-sm text-blue-600 hover:text-blue-800 font-medium transition-colors">
          View detailed progress report →
        </button>
      </div>
    </div>
  );
};

export default MasteryProgressCard;