import React from 'react';
import Card, { CardBody, CardFooter } from '../UI/Card';
import { LearningContent } from '../../types';
import { BookOpen, Clock, Video, FileText, BarChart2, MousePointer } from 'lucide-react';
import Button from '../UI/Button';

interface RecommendedContentProps {
  contentList: LearningContent[];
}

const RecommendedContent: React.FC<RecommendedContentProps> = ({ contentList }) => {
  if (!contentList.length) {
    return (
      <div className="text-center p-8 bg-gray-50 rounded-lg border border-gray-200">
        <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-3" />
        <h3 className="text-lg font-medium text-gray-900 mb-1">No Recommendations Yet</h3>
        <p className="text-gray-600">
          Complete some assessments to get personalized content recommendations.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {contentList.map((content) => (
        <Card key={content.id} hoverable>
          <div className="h-3 bg-blue-600 w-full"></div>
          <CardBody>
            <div className="mb-4">
              {getContentTypeIcon(content.type)}
            </div>
            <h3 className="font-semibold text-lg text-gray-900 mb-2">{content.title}</h3>
            <p className="text-gray-600 text-sm mb-4">{content.description}</p>
            
            <div className="flex items-center text-sm text-gray-500 mb-2">
              <Clock className="h-4 w-4 mr-2" />
              <span>{content.estimatedDuration} minutes</span>
            </div>
            
            <div className="flex flex-wrap gap-2 mb-3">
              {content.topics.map((topic) => (
                <span 
                  key={topic} 
                  className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                >
                  {topic}
                </span>
              ))}
            </div>
            
            <div className="text-xs text-gray-500 mb-4">
              <span className="font-medium">Learning styles: </span>
              {content.targetLearningStyles.join(', ')}
            </div>
          </CardBody>
          
          <CardFooter className="flex justify-between items-center">
            <div className="flex items-center">
              <span className="text-xs font-medium mr-1">Difficulty:</span>
              <div className="flex">
                {Array.from({ length: 5 }).map((_, index) => (
                  <div 
                    key={index}
                    className={`h-2 w-2 rounded-full mr-1 ${
                      index < content.difficulty 
                        ? 'bg-blue-600' 
                        : 'bg-gray-200'
                    }`}
                  />
                ))}
              </div>
            </div>
            
            <Button 
              variant="primary" 
              size="sm"
              onClick={() => window.location.href = content.url}
            >
              Start
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
};

// Helper function to get the appropriate icon based on content type
function getContentTypeIcon(type: string) {
  switch (type) {
    case 'video':
      return <Video className="h-6 w-6 text-blue-600" />;
    case 'text':
      return <FileText className="h-6 w-6 text-purple-600" />;
    case 'quiz':
      return <BarChart2 className="h-6 w-6 text-green-600" />;
    case 'interactive':
      return <MousePointer className="h-6 w-6 text-orange-600" />;
    case 'practice':
      return <BarChart2 className="h-6 w-6 text-teal-600" />;
    default:
      return <BookOpen className="h-6 w-6 text-gray-600" />;
  }
}

export default RecommendedContent;