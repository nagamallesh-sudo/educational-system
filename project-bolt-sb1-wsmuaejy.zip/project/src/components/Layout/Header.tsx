import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../../context/UserContext';
import { BookOpen, Menu, X, LogOut, User as UserIcon } from 'lucide-react';
import Button from '../UI/Button';

const Header: React.FC = () => {
  const { currentUser, isLoggedIn, logout } = useUser();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/');
    setMobileMenuOpen(false);
  };

  const handleNavigation = (path: string) => {
    navigate(path);
    setMobileMenuOpen(false);
  };
  
  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        {/* Logo */}
        <div 
          className="flex items-center cursor-pointer" 
          onClick={() => handleNavigation('/')}
        >
          <BookOpen className="h-8 w-8 text-blue-600" />
          <span className="ml-2 text-xl font-bold text-gray-900">AdaptEd</span>
        </div>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <button 
            onClick={() => handleNavigation('/')}
            className="text-gray-700 hover:text-blue-600 transition-colors"
          >
            Home
          </button>
          <button 
            onClick={() => handleNavigation('/learning-paths')}
            className="text-gray-700 hover:text-blue-600 transition-colors"
          >
            Learning Paths
          </button>
          <button 
            onClick={() => handleNavigation('/assessments')}
            className="text-gray-700 hover:text-blue-600 transition-colors"
          >
            Assessments
          </button>
          
          {isLoggedIn ? (
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                {currentUser?.profilePicture ? (
                  <img 
                    src={currentUser.profilePicture} 
                    alt={currentUser.name} 
                    className="h-8 w-8 rounded-full object-cover"
                  />
                ) : (
                  <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                    <UserIcon className="h-4 w-4 text-gray-500" />
                  </div>
                )}
                <span className="ml-2 text-sm font-medium">{currentUser?.name}</span>
              </div>
              
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleLogout}
                icon={<LogOut className="h-4 w-4" />}
              >
                Logout
              </Button>
            </div>
          ) : (
            <div className="flex items-center space-x-4">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => handleNavigation('/login')}
              >
                Login
              </Button>
              <Button 
                variant="primary" 
                size="sm" 
                onClick={() => handleNavigation('/signup')}
              >
                Sign Up
              </Button>
            </div>
          )}
        </nav>
        
        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-gray-700"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
      </div>
      
      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white shadow-lg absolute top-full left-0 w-full">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <button 
              onClick={() => handleNavigation('/')}
              className="text-gray-700 hover:text-blue-600 py-2 transition-colors"
            >
              Home
            </button>
            <button 
              onClick={() => handleNavigation('/learning-paths')}
              className="text-gray-700 hover:text-blue-600 py-2 transition-colors"
            >
              Learning Paths
            </button>
            <button 
              onClick={() => handleNavigation('/assessments')}
              className="text-gray-700 hover:text-blue-600 py-2 transition-colors"
            >
              Assessments
            </button>
            
            {isLoggedIn ? (
              <div className="flex flex-col space-y-4 pt-4 border-t border-gray-200">
                <div className="flex items-center">
                  {currentUser?.profilePicture ? (
                    <img 
                      src={currentUser.profilePicture} 
                      alt={currentUser.name} 
                      className="h-8 w-8 rounded-full object-cover"
                    />
                  ) : (
                    <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                      <UserIcon className="h-4 w-4 text-gray-500" />
                    </div>
                  )}
                  <span className="ml-2 text-sm font-medium">{currentUser?.name}</span>
                </div>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleLogout}
                  icon={<LogOut className="h-4 w-4" />}
                  fullWidth
                >
                  Logout
                </Button>
              </div>
            ) : (
              <div className="flex flex-col space-y-2 pt-4 border-t border-gray-200">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => handleNavigation('/login')}
                  fullWidth
                >
                  Login
                </Button>
                <Button 
                  variant="primary" 
                  size="sm" 
                  onClick={() => handleNavigation('/signup')}
                  fullWidth
                >
                  Sign Up
                </Button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;