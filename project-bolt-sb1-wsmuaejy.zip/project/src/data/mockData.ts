import { 
  User, 
  UserProfile, 
  LearningContent, 
  Assessment, 
  LearningPath,
  Recommendation,
  AssessmentQuestion 
} from '../types';

// Mock users
export const mockUsers: User[] = [
  {
    id: 'user1',
    name: 'Alex Johnson',
    email: 'alex@example.com',
    profilePicture: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=600'
  },
  {
    id: 'user2',
    name: 'Taylor Smith',
    email: 'taylor@example.com',
    profilePicture: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600'
  }
];

// Mock user profiles
export const mockUserProfiles: UserProfile[] = [
  {
    user: mockUsers[0],
    learningPreferences: [
      { style: 'visual', strength: 80 },
      { style: 'auditory', strength: 40 },
      { style: 'reading', strength: 65 },
      { style: 'kinesthetic', strength: 55 }
    ],
    completedAssessments: ['assessment1'],
    strengths: ['mathematics', 'critical thinking'],
    weaknesses: ['memorization', 'foreign languages'],
    currentMastery: {
      'algebra': 75,
      'calculus': 40,
      'statistics': 65,
      'physics': 50,
      'computer science': 85
    }
  }
];

// Mock learning content
export const mockLearningContent: LearningContent[] = [
  {
    id: 'content1',
    title: 'Introduction to Algebra',
    description: 'Basic concepts and operations in algebra',
    type: 'video',
    targetLearningStyles: ['visual', 'auditory'],
    difficulty: 2,
    estimatedDuration: 15,
    prerequisites: [],
    topics: ['algebra', 'mathematics'],
    url: '/content/algebra-intro'
  },
  {
    id: 'content2',
    title: 'Advanced Algebraic Equations',
    description: 'Solving complex equations and applications',
    type: 'interactive',
    targetLearningStyles: ['kinesthetic', 'visual'],
    difficulty: 3,
    estimatedDuration: 25,
    prerequisites: ['content1'],
    topics: ['algebra', 'mathematics'],
    url: '/content/algebra-advanced'
  },
  {
    id: 'content3',
    title: 'Fundamentals of Calculus',
    description: 'Introduction to limits, derivatives, and integrals',
    type: 'text',
    targetLearningStyles: ['reading', 'visual'],
    difficulty: 4,
    estimatedDuration: 30,
    prerequisites: ['content1', 'content2'],
    topics: ['calculus', 'mathematics'],
    url: '/content/calculus-fundamentals'
  },
  {
    id: 'content4',
    title: 'Statistical Analysis Methods',
    description: 'Overview of common statistical methods and their applications',
    type: 'practice',
    targetLearningStyles: ['kinesthetic', 'reading'],
    difficulty: 3,
    estimatedDuration: 20,
    prerequisites: [],
    topics: ['statistics', 'mathematics'],
    url: '/content/statistics-analysis'
  }
];

// Mock assessment questions
export const mockAssessmentQuestions: AssessmentQuestion[] = [
  {
    id: 'question1',
    text: 'Solve for x: 2x + 5 = 13',
    type: 'multiple-choice',
    options: ['x = 3', 'x = 4', 'x = 5', 'x = 6'],
    correctAnswer: 'x = 4',
    points: 10,
    topic: 'algebra'
  },
  {
    id: 'question2',
    text: 'The derivative of f(x) = x² is f\'(x) = 2x',
    type: 'true-false',
    options: ['True', 'False'],
    correctAnswer: 'True',
    points: 5,
    topic: 'calculus'
  },
  {
    id: 'question3',
    text: 'Explain the concept of standard deviation and why it\'s important in statistical analysis.',
    type: 'open-ended',
    points: 15,
    topic: 'statistics'
  }
];

// Mock assessments
export const mockAssessments: Assessment[] = [
  {
    id: 'assessment1',
    title: 'Algebra Knowledge Check',
    description: 'Test your understanding of basic algebraic concepts',
    type: 'diagnostic',
    questions: [mockAssessmentQuestions[0]],
    topics: ['algebra', 'mathematics']
  },
  {
    id: 'assessment2',
    title: 'Calculus Mid-term',
    description: 'Comprehensive assessment of calculus fundamentals',
    type: 'summative',
    questions: [mockAssessmentQuestions[1]],
    topics: ['calculus', 'mathematics']
  },
  {
    id: 'assessment3',
    title: 'Statistics Quiz',
    description: 'Quick check on statistical concepts',
    type: 'formative',
    questions: [mockAssessmentQuestions[2]],
    topics: ['statistics', 'mathematics']
  }
];

// Mock learning paths
export const mockLearningPaths: LearningPath[] = [
  {
    id: 'path1',
    title: 'Algebra Mastery',
    description: 'Complete path to master algebraic concepts',
    topics: ['algebra', 'mathematics'],
    contentSequence: [mockLearningContent[0], mockLearningContent[1]],
    assessments: [mockAssessments[0]]
  },
  {
    id: 'path2',
    title: 'Calculus Foundations',
    description: 'Essential calculus concepts for beginners',
    topics: ['calculus', 'mathematics'],
    contentSequence: [mockLearningContent[2]],
    assessments: [mockAssessments[1]]
  }
];

// Mock recommendations
export const mockRecommendations: Recommendation[] = [
  {
    id: 'rec1',
    userId: 'user1',
    contentId: 'content3',
    reason: 'Based on your strong performance in algebra',
    priority: 4,
    timestamp: new Date()
  },
  {
    id: 'rec2',
    userId: 'user1',
    contentId: 'content4',
    reason: 'This will help improve your weaknesses in memorization',
    priority: 5,
    timestamp: new Date()
  }
];