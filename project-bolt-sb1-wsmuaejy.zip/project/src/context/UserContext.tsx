import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User, UserProfile } from '../types';
import { mockUserProfiles } from '../data/mockData';

interface UserContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  isLoggedIn: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
}

const UserContext = createContext<UserContextType>({
  currentUser: null,
  userProfile: null,
  isLoggedIn: false,
  login: async () => false,
  signup: async () => false,
  logout: () => {}
});

export const useUser = () => useContext(UserContext);

interface UserProviderProps {
  children: ReactNode;
}

export const UserProvider: React.FC<UserProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [profiles, setProfiles] = useState(mockUserProfiles);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const profile = profiles.find(profile => profile.user.email === email);
      
      if (profile) {
        setCurrentUser(profile.user);
        setUserProfile(profile);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const signup = async (name: string, email: string, password: string): Promise<boolean> => {
    try {
      // Check if user already exists
      if (profiles.some(profile => profile.user.email === email)) {
        return false;
      }

      // Create new user and profile
      const newUser: User = {
        id: `user${profiles.length + 1}`,
        name,
        email
      };

      const newProfile: UserProfile = {
        user: newUser,
        learningPreferences: [
          { style: 'visual', strength: 25 },
          { style: 'auditory', strength: 25 },
          { style: 'reading', strength: 25 },
          { style: 'kinesthetic', strength: 25 }
        ],
        completedAssessments: [],
        strengths: [],
        weaknesses: [],
        currentMastery: {}
      };

      // Update profiles state
      setProfiles(prev => [...prev, newProfile]);
      
      // Log in the new user
      setCurrentUser(newUser);
      setUserProfile(newProfile);
      
      return true;
    } catch (error) {
      console.error('Signup error:', error);
      return false;
    }
  };

  const logout = () => {
    setCurrentUser(null);
    setUserProfile(null);
  };

  return (
    <UserContext.Provider value={{
      currentUser,
      userProfile,
      isLoggedIn: !!currentUser,
      login,
      signup,
      logout
    }}>
      {children}
    </UserContext.Provider>
  );
};