import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { LearningContent, Assessment, LearningPath, Recommendation } from '../types';
import { mockLearningContent, mockAssessments, mockLearningPaths, mockRecommendations } from '../data/mockData';
import { useUser } from './UserContext';

interface LearningContextType {
  content: LearningContent[];
  assessments: Assessment[];
  learningPaths: LearningPath[];
  recommendations: Recommendation[];
  currentContent: LearningContent | null;
  currentAssessment: Assessment | null;
  loadContent: (contentId: string) => void;
  loadAssessment: (assessmentId: string) => void;
  getRecommendedContent: () => LearningContent[];
}

const LearningContext = createContext<LearningContextType>({
  content: [],
  assessments: [],
  learningPaths: [],
  recommendations: [],
  currentContent: null,
  currentAssessment: null,
  loadContent: () => {},
  loadAssessment: () => {},
  getRecommendedContent: () => []
});

export const useLearning = () => useContext(LearningContext);

interface LearningProviderProps {
  children: ReactNode;
}

export const LearningProvider: React.FC<LearningProviderProps> = ({ children }) => {
  const { currentUser } = useUser();
  const [content, setContent] = useState<LearningContent[]>(mockLearningContent);
  const [assessments, setAssessments] = useState<Assessment[]>(mockAssessments);
  const [learningPaths, setLearningPaths] = useState<LearningPath[]>(mockLearningPaths);
  const [recommendations, setRecommendations] = useState<Recommendation[]>(mockRecommendations);
  const [currentContent, setCurrentContent] = useState<LearningContent | null>(null);
  const [currentAssessment, setCurrentAssessment] = useState<Assessment | null>(null);

  // Update recommendations when user changes
  useEffect(() => {
    if (currentUser) {
      // In a real app, fetch recommendations from API based on current user
      const userRecommendations = mockRecommendations.filter(rec => rec.userId === currentUser.id);
      setRecommendations(userRecommendations);
    } else {
      setRecommendations([]);
    }
  }, [currentUser]);

  const loadContent = (contentId: string) => {
    const foundContent = content.find(c => c.id === contentId);
    if (foundContent) {
      setCurrentContent(foundContent);
    }
  };

  const loadAssessment = (assessmentId: string) => {
    const foundAssessment = assessments.find(a => a.id === assessmentId);
    if (foundAssessment) {
      setCurrentAssessment(foundAssessment);
    }
  };

  const getRecommendedContent = (): LearningContent[] => {
    if (!currentUser) return [];

    const recommendedIds = recommendations
      .sort((a, b) => b.priority - a.priority)
      .map(rec => rec.contentId);
    
    return recommendedIds
      .map(id => content.find(c => c.id === id))
      .filter((c): c is LearningContent => c !== undefined);
  };

  return (
    <LearningContext.Provider value={{
      content,
      assessments,
      learningPaths,
      recommendations,
      currentContent,
      currentAssessment,
      loadContent,
      loadAssessment,
      getRecommendedContent
    }}>
      {children}
    </LearningContext.Provider>
  );
};