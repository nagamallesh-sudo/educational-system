import React, { useState, useEffect } from 'react';
import { useUser } from '../context/UserContext';
import { useLearning } from '../context/LearningContext';
import Layout from '../components/Layout/Layout';
import LearningStyleChart from '../components/Dashboard/LearningStyleChart';
import MasteryProgressCard from '../components/Dashboard/MasteryProgressCard';
import RecommendedContent from '../components/Dashboard/RecommendedContent';
import LearningPathCard from '../components/Dashboard/LearningPathCard';
import { ArrowRight, BookOpen, Lightbulb, User } from 'lucide-react';
import Button from '../components/UI/Button';

const Dashboard: React.FC = () => {
  const { userProfile, isLoggedIn } = useUser();
  const { getRecommendedContent, learningPaths } = useLearning();
  const [recommendedContent, setRecommendedContent] = useState([]);
  
  useEffect(() => {
    if (isLoggedIn) {
      const content = getRecommendedContent();
      setRecommendedContent(content);
    }
  }, [isLoggedIn, getRecommendedContent]);
  
  // If not logged in, redirect to login
  useEffect(() => {
    if (!isLoggedIn) {
      window.location.href = '/login';
    }
  }, [isLoggedIn]);
  
  if (!isLoggedIn || !userProfile) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }
  
  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Welcome Header */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center mr-4">
              <User className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Welcome back, {userProfile.user.name.split(' ')[0]}</h1>
              <p className="text-gray-600">Here's an overview of your personalized learning journey</p>
            </div>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6 border-l-4 border-blue-500">
            <div className="flex items-start">
              <div className="p-2 rounded-lg bg-blue-100 mr-4">
                <BookOpen className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">Completed Lessons</p>
                <p className="text-2xl font-semibold">12</p>
                <p className="text-xs text-green-600 mt-1">↑ 20% from last week</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6 border-l-4 border-purple-500">
            <div className="flex items-start">
              <div className="p-2 rounded-lg bg-purple-100 mr-4">
                <Lightbulb className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">Learning Streak</p>
                <p className="text-2xl font-semibold">5 days</p>
                <p className="text-xs text-green-600 mt-1">↑ 2 days from previous best</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6 border-l-4 border-teal-500">
            <div className="flex items-start">
              <div className="p-2 rounded-lg bg-teal-100 mr-4">
                <BookOpen className="h-5 w-5 text-teal-600" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">Current Focus</p>
                <p className="text-2xl font-semibold">Algebra</p>
                <p className="text-xs text-blue-600 mt-1">75% to mastery</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Main Dashboard Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Sidebar: User Profile & Mastery */}
          <div className="lg:col-span-1 space-y-6">
            <LearningStyleChart learningPreferences={userProfile.learningPreferences} />
            <MasteryProgressCard masteryData={userProfile.currentMastery} />
          </div>
          
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Recommended Content */}
            <div>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-900">Recommended For You</h2>
                <Button 
                  variant="text" 
                  size="sm"
                  icon={<ArrowRight className="h-4 w-4" />}
                  iconPosition="right"
                >
                  View All
                </Button>
              </div>
              <RecommendedContent contentList={recommendedContent} />
            </div>
            
            {/* Learning Paths */}
            <div>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-900">Your Learning Paths</h2>
                <Button 
                  variant="text" 
                  size="sm"
                  icon={<ArrowRight className="h-4 w-4" />}
                  iconPosition="right"
                >
                  View All
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {learningPaths.map((path) => (
                  <LearningPathCard 
                    key={path.id} 
                    path={path} 
                    progress={path.id === 'path1' ? 45 : 0} 
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;