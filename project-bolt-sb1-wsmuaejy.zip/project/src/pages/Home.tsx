import React from 'react';
import { ArrowRight, BookOpen, Brain, BarChart3, Users, CheckCircle, ChevronRight } from 'lucide-react';
import Layout from '../components/Layout/Layout';
import Button from '../components/UI/Button';

const Home: React.FC = () => {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-purple-600 text-white overflow-hidden">
        <div className="absolute inset-0 bg-pattern opacity-10"></div>
        <div className="container mx-auto px-4 py-20 lg:py-32 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="max-w-xl">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                Personalized Learning That Adapts To <span className="text-teal-300">You</span>
              </h1>
              <p className="text-lg md:text-xl mb-8 text-blue-100 leading-relaxed">
                AdaptEd uses AI to understand your unique learning style and creates a customized experience that helps you learn faster and retain more knowledge.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  variant="primary"
                  size="lg"
                  className="bg-white text-blue-600 hover:bg-blue-50"
                  onClick={() => window.location.href = '/signup'}
                >
                  Get Started Free
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-white text-white hover:bg-white/10"
                  onClick={() => window.location.href = '/login'}
                >
                  Log In
                </Button>
              </div>
              <div className="mt-8 flex items-center text-sm">
                <CheckCircle className="h-5 w-5 text-teal-300 mr-2" />
                <span>No credit card required</span>
              </div>
            </div>
            
            <div className="flex justify-center">
              <div className="bg-white rounded-lg shadow-xl overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/5212335/pexels-photo-5212335.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                  alt="AI-powered learning" 
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Revolutionize Your Learning Experience</h2>
            <p className="text-lg text-gray-600">
              Our AI-powered platform adapts to your learning style, pace, and preferences to create a truly personalized educational journey.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 transition-all duration-300 hover:shadow-md">
              <div className="p-3 bg-blue-100 rounded-lg inline-block mb-4">
                <Brain className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">AI-Powered Analysis</h3>
              <p className="text-gray-600 mb-4">
                Our intelligent system analyzes your learning patterns to identify your unique style, strengths, and areas for improvement.
              </p>
              <a href="#" className="inline-flex items-center text-blue-600 font-medium hover:text-blue-800">
                Learn more <ChevronRight className="h-4 w-4 ml-1" />
              </a>
            </div>
            
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 transition-all duration-300 hover:shadow-md">
              <div className="p-3 bg-purple-100 rounded-lg inline-block mb-4">
                <BookOpen className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Personalized Pathways</h3>
              <p className="text-gray-600 mb-4">
                Experience customized learning journeys that adapt to your progress, learning preferences, and goals.
              </p>
              <a href="#" className="inline-flex items-center text-blue-600 font-medium hover:text-blue-800">
                Learn more <ChevronRight className="h-4 w-4 ml-1" />
              </a>
            </div>
            
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 transition-all duration-300 hover:shadow-md">
              <div className="p-3 bg-teal-100 rounded-lg inline-block mb-4">
                <BarChart3 className="h-6 w-6 text-teal-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Real-time Feedback</h3>
              <p className="text-gray-600 mb-4">
                Get instant, meaningful feedback on your progress and adaptive recommendations to optimize your learning.
              </p>
              <a href="#" className="inline-flex items-center text-blue-600 font-medium hover:text-blue-800">
                Learn more <ChevronRight className="h-4 w-4 ml-1" />
              </a>
            </div>
          </div>
        </div>
      </section>
      
      {/* How It Works */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">How AdaptEd Works</h2>
            <p className="text-lg text-gray-600">
              A simple 4-step process to revolutionize the way you learn
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                step: '01',
                title: 'Initial Assessment',
                description: 'Complete a series of engaging assessments to identify your learning preferences and baseline knowledge.'
              },
              {
                step: '02',
                title: 'AI Analysis',
                description: 'Our AI analyzes your learning patterns to create a comprehensive profile of how you learn best.'
              },
              {
                step: '03',
                title: 'Custom Learning Path',
                description: 'Receive a personalized learning journey with content and activities tailored to your individual needs.'
              },
              {
                step: '04',
                title: 'Continuous Adaptation',
                description: 'The system continuously evolves with you, adjusting to your progress and changing learning patterns.'
              }
            ].map((item, index) => (
              <div key={index} className="relative">
                <div className="text-6xl font-bold text-gray-100 absolute -top-10 left-0">{item.step}</div>
                <div className="relative z-10 pt-4">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{item.title}</h3>
                  <p className="text-gray-600">
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">What Our Users Say</h2>
            <p className="text-lg text-gray-600">
              Thousands of learners have transformed their educational experience with AdaptEd
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                quote: "AdaptEd completely changed how I approach learning. The personalized content and adaptive pace helped me master concepts I had struggled with for years.",
                author: "Sarah J.",
                role: "Medical Student",
                image: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=600"
              },
              {
                quote: "As a teacher, I've seen incredible progress in my students since implementing AdaptEd. The platform's ability to cater to different learning styles has been revolutionary.",
                author: "Michael T.",
                role: "High School Teacher",
                image: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=600"
              },
              {
                quote: "The real-time feedback and adaptive assessments have helped me identify and overcome my weaknesses. I'm now performing at the top of my class thanks to AdaptEd.",
                author: "Jessica L.",
                role: "Engineering Student",
                image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600"
              }
            ].map((testimonial, index) => (
              <div key={index} className="bg-white rounded-lg p-8 shadow border border-gray-100">
                <div className="mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <span key={star} className="text-yellow-400">★</span>
                  ))}
                </div>
                <p className="text-gray-600 mb-6 italic">"{testimonial.quote}"</p>
                <div className="flex items-center">
                  <img 
                    src={testimonial.image}
                    alt={testimonial.author}
                    className="h-10 w-10 rounded-full object-cover mr-3"
                  />
                  <div>
                    <h4 className="font-medium text-gray-900">{testimonial.author}</h4>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Transform Your Learning Experience?</h2>
            <p className="text-xl mb-8 text-blue-100">
              Join thousands of learners who have discovered the power of personalized, adaptive learning with AdaptEd.
            </p>
            <Button
              variant="primary"
              size="lg"
              className="bg-white text-blue-600 hover:bg-blue-50"
              icon={<ArrowRight className="h-5 w-5" />}
              iconPosition="right"
              onClick={() => window.location.href = '/signup'}
            >
              Get Started for Free
            </Button>
            <p className="mt-4 text-sm text-blue-100">No credit card required. Free 14-day trial.</p>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Home;