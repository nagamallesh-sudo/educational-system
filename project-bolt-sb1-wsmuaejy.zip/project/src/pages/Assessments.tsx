import React from 'react';
import { useLearning } from '../context/LearningContext';
import Layout from '../components/Layout/Layout';
import Card, { CardBody } from '../components/UI/Card';
import Button from '../components/UI/Button';
import { ClipboardCheck, Clock, Tag } from 'lucide-react';

const Assessments: React.FC = () => {
  const { assessments } = useLearning();

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Assessments</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {assessments.map((assessment) => (
            <Card key={assessment.id} hoverable>
              <CardBody>
                <div className="flex items-start mb-4">
                  <div className="p-2 rounded-lg bg-purple-100 mr-4">
                    <ClipboardCheck className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{assessment.title}</h3>
                    <p className="text-gray-600 text-sm mb-4">{assessment.description}</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-2" />
                    <span>{assessment.questions.length} questions</span>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {assessment.topics.map((topic) => (
                      <span
                        key={topic}
                        className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800"
                      >
                        <Tag className="h-3 w-3 mr-1" />
                        {topic}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-6">
                  <Button
                    variant="primary"
                    fullWidth
                    onClick={() => window.location.href = `/assessment/${assessment.id}`}
                  >
                    Start Assessment
                  </Button>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default Assessments;