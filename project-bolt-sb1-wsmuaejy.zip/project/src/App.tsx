import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { UserProvider } from './context/UserContext';
import { LearningProvider } from './context/LearningContext';
import Home from './pages/Home';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import LearningPaths from './pages/LearningPaths';
import Assessments from './pages/Assessments';

function App() {
  return (
    <UserProvider>
      <LearningProvider>
        <Router>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/learning-paths" element={<LearningPaths />} />
            <Route path="/assessments" element={<Assessments />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Router>
      </LearningProvider>
    </UserProvider>
  );
}

export default App;