// User types
export interface User {
  id: string;
  name: string;
  email: string;
  profilePicture?: string;
}

// Learning style types
export type LearningStyle = 'visual' | 'auditory' | 'reading' | 'kinesthetic';

export interface LearningPreference {
  style: LearningStyle;
  strength: number; // 0-100
}

export interface UserProfile {
  user: User;
  learningPreferences: LearningPreference[];
  completedAssessments: string[];
  strengths: string[];
  weaknesses: string[];
  currentMastery: Record<string, number>; // topic -> mastery level (0-100)
}

// Content types
export type ContentType = 'video' | 'text' | 'quiz' | 'interactive' | 'practice';

export interface LearningContent {
  id: string;
  title: string;
  description: string;
  type: ContentType;
  targetLearningStyles: LearningStyle[];
  difficulty: number; // 1-5
  estimatedDuration: number; // in minutes
  prerequisites: string[];
  topics: string[];
  url: string;
}

// Assessment types
export interface Assessment {
  id: string;
  title: string;
  description: string;
  type: 'diagnostic' | 'formative' | 'summative';
  questions: AssessmentQuestion[];
  topics: string[];
}

export interface AssessmentQuestion {
  id: string;
  text: string;
  type: 'multiple-choice' | 'true-false' | 'open-ended';
  options?: string[];
  correctAnswer?: string | string[];
  points: number;
  topic: string;
}

// Learning path types
export interface LearningPath {
  id: string;
  title: string;
  description: string;
  topics: string[];
  contentSequence: LearningContent[];
  assessments: Assessment[];
}

// User interaction types
export interface UserInteraction {
  userId: string;
  contentId: string;
  type: 'view' | 'complete' | 'skip' | 'bookmark' | 'seek-help';
  timestamp: Date;
  duration?: number; // in seconds
  score?: number; // for assessments
}

// Recommendation types
export interface Recommendation {
  id: string;
  userId: string;
  contentId: string;
  reason: string;
  priority: number; // 1-5
  timestamp: Date;
}